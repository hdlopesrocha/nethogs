This a version of Nethogs that does not uses ncurses, by other words, it's very easy to parse.

I did this fork because I had to collect network information for my master thesis.

By the way, the man pages are wrong, some functionalities were removed.

Enjoy ;-)

